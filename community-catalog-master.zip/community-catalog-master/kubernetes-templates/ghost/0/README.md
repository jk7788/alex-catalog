# Ghost

Ghost is a platform dedicated to one thing: Publishing. It's beautifully designed, completely customisable and completely Open Source. Ghost allows you to write and publish your own blog, giving you the tools to make it easy and even fun to do.

This is a Ghost deployment on Kubernetes environment, using MySQL as backend store for the blogging paltform.
