# MongoDB

MongoDB is an open-source, document database designed for ease of development and scaling.

This is a MongoDB replica set deployment on Kubernetes environment, it will create MongoDB replica set with the ability to scale it in the future.
