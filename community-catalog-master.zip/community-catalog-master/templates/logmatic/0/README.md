# Logmatic Agent

This template deploys a [Logmatic](https://www.logmatic.io/) agent stack consisting of the official [logmatic-docker](https://github.com/logmatic/logmatic-docker) image
