# Gocd server (Experimental)

### Info:

 This template creates and configure a gocd server instance.

 You can add a local or a convoy-gluster volume to retain gocd-server data. 
 
### Usage:

 Select gocd-server from catalog. 
 
 Enter the mem parameters, volume and volume driver.
 
 Click deploy.
 
 gocd-server can now be accessed over the Rancher network. 
 
