# GitLab CE

GitLab CE is a free alternative to GitHub

Stack based on official GitLab version: latest

https://hub.docker.com/r/gitlab/gitlab-ce/


