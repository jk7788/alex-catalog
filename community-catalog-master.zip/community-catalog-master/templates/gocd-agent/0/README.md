# Gocd agent (Experimental)

### Info:

 This template creates and configure a gocd server agent.
 
 
### Usage:

 Select gocd-agent from catalog. 
 
 Enter the mem parameters, gocd-server stack/service and port.
 
 Click deploy.
 
 gocd-agent can now be accessed over the Rancher network. 
 
