from distutils.core import setup

setup(
    name='Rancher Catalog YAML Integration Tests',
    version='0.1',
    packages=[
      'core',
    ],
    license='ASL 2.0',
)
